import java.util.ArrayList;
import java.util.Scanner;

public class Owner {
    private String name = "Noname";
    private String surname = "Default";
    private String patronymic = "Nothing";
    private String numberBicycle;
    //private Date date = new Date();
    //private String numberPhone;
    private int id;

    public Owner set(int lastId){
        Owner owner = new Owner();
        Scanner text = new Scanner(System.in);

        do{
            System.out.println("Введите Фамилию: ");
            this.surname = text.nextLine();
        }
        while(this.surname.equals("") || this.surname.equals(" "));

        do{
            System.out.println("Введите Имя: ");
            this.name = text.nextLine();
        }
        while(this.name.equals("") || this.name.equals(" "));

        System.out.println("Введите Отчество(Не обязательно): ");
        String temp = text.nextLine();

        if(temp.equals("") || temp.equals(" ")) System.out.println("Вы предпочли не вводить Отчество!");
        else this.patronymic = temp;

        do{
            System.out.println("Введите Серийный номер велосипеда: ");
            this.numberBicycle = text.nextLine();
        }
        while(this.numberBicycle.equals("") || this.numberBicycle.equals(" "));

        /*do{
            System.out.println("Введите Номер мобильного телефона: ");
            this.numberPhone = text.nextLine();
        }
        while(this.numberPhone.equals("") || this.numberPhone.equals(" "));*/

        this.id = lastId++;

        return owner;
    }

    public void set(String name, String surname, String patronymic, String numberBicycle, String i){
        this.name = name;
        this.surname = surname;
        this.patronymic = patronymic;
        this.numberBicycle = numberBicycle;
        this.id = Integer.parseInt(i);
    }


    public ArrayList <String> get(ArrayList <Owner> owners){
        String str;
        ArrayList <String> arrayStr = new ArrayList<String>();
        Scanner in = new Scanner(System.in);

        System.out.println("Введите номер записи которую хотите получить:\n Если вы хотите вывести все записи введите параметр: all");
        str = in.nextLine();

        if(str.equals("all")){
            for(Owner owner:owners){
                arrayStr.add(owner.name + " " + owner.surname + " " + owner.patronymic + /*" " + owner.numberPhone +*/ " " + owner.numberBicycle/* + " " + owner.date*/ + owner.id);
            }
        }
        else{
            int id = Integer.parseInt(str) - 1;

            if(id >= 0 && id < owners.size()){
                arrayStr.add(owners.get(id).name + " " + owners.get(id).surname + " " + owners.get(id).patronymic + /*" " + owners.get(id).numberPhone +*/ " " + owners.get(id).numberBicycle /*+ " " + owners.get(id).date*/);
            }
            else{
                System.out.println("Не найдена запись с " + id + " номером");
            }
        }
        return arrayStr; //warning! return ArrayList with 1 arguments!
    }

    public void replace(ArrayList <Owner> owners){
        Scanner in = new Scanner(System.in);

        int id;
        String nameField, replacement;

        System.out.print("Введите название поля, значение которого вы хотите изменить... ");
        nameField = in.nextLine();

        Scanner in2 = new Scanner(System.in);
        System.out.print("Введите номер записи, в которой вы хотите изменить поле... ");
        id = in2.nextInt();
        id -= 1;

        Scanner in3 = new Scanner(System.in);
        System.out.print("Введите новое значение поля... ");
        replacement = in3.nextLine();

        switch(nameField){
            case("name"):
            {
                String example = "N";

                System.out.println("Вы точно хотите изменить это поле? нажмите Y - если да или N - если нет... ");
                example = in.nextLine();

                if(example.equals("Y")){
                    owners.get(id).name.equals(replacement);
                    break;
                }
                else{
                    break;
                }
            }

            case("surname"):
            {
                String example = "N";
                System.out.println("Вы точно хотите изменить это поле? нажмите Y - если да или N - если нет... ");
                example = in.nextLine();

                if(example.equals("Y")){
                    owners.get(id).surname.equals(replacement);
                    break;
                }
                else{
                    break;
                }
            }
            case("patronymic"):
            {
                String example = "N";
                System.out.println("Вы точно хотите изменить это поле? нажмите Y - если да или N - если нет... ");
                example = in.nextLine();

                if(example.equals("Y")){
                    owners.get(id).patronymic.equals(replacement);
                    break;
                }
                else{
                    break;
                }
            }

            default:
            {
                System.out.println("такого поля не найдено! Или его невозможно изменить!");
            }
        }

    }

    public String getNumberBicycle(){
        return this.numberBicycle;
    }

    public int getId(){
        return this.id;
    }

    public String getName(){ return this.name; }

    public String getSurname(){
        return this.surname;
    }

    public String getPatronymic(){
        return this.patronymic;
    }
}
