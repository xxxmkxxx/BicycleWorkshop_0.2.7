import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeoutException;

public class Repair{
    private int cost;
    //private Date date = new Date();
    private String numberBicycle;

    public Repair set(Owner customer){
        Repair repair = new Repair();
        Scanner text = new Scanner(System.in);

        do{
            System.out.println("Введите примерное состояние велосипеда в процентах: ");
            this.cost = text.nextInt();
        }
        while(cost <= 100);

        this.numberBicycle = customer.getNumberBicycle();

        return repair;
    }

    public void set(String cost){
        this.cost = Integer.parseInt(cost);
    }

    public ArrayList <String> get(ArrayList <Repair> repairs){
        String str;
        ArrayList <String> arrayStr = new ArrayList<String>();
        Scanner in = new Scanner(System.in);

        System.out.println("Введите номер записи которую хотите получить:\n Если вы хотите вывести все записи введите параметр: all");
        str = in.nextLine();

        if(str.equals("all")){
            for(Repair repair:repairs){
                arrayStr.add(repair.numberBicycle + " " + repair.cost);
            }
        }
        else{
            int id = Integer.parseInt(str);

            if(id >= 0 && id < repairs.size()){
                arrayStr.add(repairs.get(id).numberBicycle + " " + repairs.get(id).cost);
            }
            else{
                System.out.println("Не найдена запись с " + id + " номером");
            }
        }
        return arrayStr; //warning! return ArrayList with 1 arguments!
    }

    public void replace(ArrayList <Repair> repairs){
        Scanner in = new Scanner(System.in);

        int id;
        String nameField, replacement;

        System.out.print("Введите название поля, значение которого вы хотите изменить... ");
        nameField = in.nextLine();

        Scanner in2 = new Scanner(System.in);
        System.out.print("Введите номер записи, в которой вы хотите изменить поле... ");
        id = in2.nextInt();
        id -= 1;

        Scanner in3 = new Scanner(System.in);
        System.out.print("Введите новое значение поля... ");
        replacement = in3.nextLine();

        switch(nameField){
            case("cost"):
            {
                String example = "N";

                System.out.println("Вы точно хотите изменить это поле? нажмите Y - если да или N - если нет... ");
                example = in.nextLine();

                if(example.equals("Y")){
                    repairs.get(id).cost = Integer.parseInt(replacement);
                    break;
                }
                else{
                    break;
                }
            }

            default:
            {
                System.out.println("такого поля не найдено! Или его невозможно изменить!");
            }
        }

    }

    public int getCost(){
        return this.cost;
    }
}
