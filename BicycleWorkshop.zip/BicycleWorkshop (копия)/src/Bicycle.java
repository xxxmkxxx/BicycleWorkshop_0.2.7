import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class Bicycle {
    private String numberBicycle;
    private int state;
    private String breakage;

    static Bicycle set(Owner customer){
        Bicycle bicycle = new Bicycle();
        Scanner text = new Scanner(System.in);

        do{
            System.out.println("Введите примерное состояние велосипеда в процентах: ");
            bicycle.state = text.nextInt();
        }
        while(bicycle.state <= 0);

        do{
            System.out.println("Введите название неисправной детали: ");
            bicycle.breakage = text.nextLine();
        }
        while(bicycle.breakage.equals("") || bicycle.breakage.equals(" "));

        bicycle.numberBicycle = customer.getNumberBicycle();

        return bicycle;
    }

    public void set(String state, String breakage){
        this.state = Integer.parseInt(state);
        this.breakage = breakage;
    }

    public Bicycle changePar(Bicycle bicycle){
        Scanner parametrs = new Scanner(System.in);

        System.out.println("Введите название параметра, который хотите изменить: ");
        String parameter = parametrs.nextLine();

        System.out.println("Введите то,на что вы хотели заменить: ");
        String replacement = parametrs.nextLine();

        switch(parameter){
            case("numberBicycle"):
            {
                this.numberBicycle = replacement;
                break;
            }
            case("breakage"):
            {
                this.breakage = replacement;
                break;
            }
            default:
            {
                System.out.println("Введённое поле не найдено!");
            }
        }

        return bicycle;
    }

    void changePar(String parameter, int replacement){
        switch(parameter){
            case("state"):
            {
                this.state = replacement;
                break;
            }
            default:
            {
                System.out.println("Введённое поле не найдено!");
            }
        }
    }

    public ArrayList <String> get(ArrayList <Bicycle> bicycles){
        String str;
        ArrayList <String> arrayStr = new ArrayList<String>();
        Scanner in = new Scanner(System.in);

        System.out.println("Введите номер записи которую хотите получить:\n Если вы хотите вывести все записи введите параметр: all");
        str = in.nextLine();

        if(str.equals("all")){
            for(Bicycle bicycle:bicycles){
                arrayStr.add(bicycle.numberBicycle + " " + bicycle.breakage + " " + bicycle.state);
            }
        }
        else{
            int id = Integer.parseInt(str);

            if(id >= 0 && id < bicycles.size()){
                arrayStr.add(bicycles.get(id).numberBicycle + " " + bicycles.get(id).breakage + " " + bicycles.get(id).state);
            }
            else{
                System.out.println("Не найдена запись с " + id + " номером");
            }
        }
        return arrayStr; //warning! return ArrayList with 1 arguments!
    }

    public void replace(ArrayList <Bicycle> bicycles){
        Scanner in = new Scanner(System.in);

        int id;
        String nameField, replacement;

        System.out.print("Введите название поля, значение которого вы хотите изменить... ");
        nameField = in.nextLine();

        Scanner in2 = new Scanner(System.in);
        System.out.print("Введите номер записи, в которой вы хотите изменить поле... ");
        id = in2.nextInt();
        id -= 1;

        Scanner in3 = new Scanner(System.in);
        System.out.print("Введите новое значение поля... ");
        replacement = in3.nextLine();

        switch(nameField){
            case("state"):
            {
                String example = "N";

                System.out.println("Вы точно хотите изменить это поле? нажмите Y - если да или N - если нет... ");
                example = in.nextLine();

                if(example.equals("Y")){
                    bicycles.get(id).state = Integer.parseInt(replacement);
                    break;
                }
                else{
                    break;
                }
            }

            case("breakage"):
            {
                String example = "N";
                System.out.println("Вы точно хотите изменить это поле? нажмите Y - если да или N - если нет... ");
                example = in.nextLine();

                if(example.equals("Y")){
                    bicycles.get(id).breakage = replacement;
                    break;
                }
                else{
                    break;
                }
            }
            default:
            {
                System.out.println("такого поля не найдено! Или его невозможно изменить!");
            }
        }

    }

    public int getState(){
        return state;
    }

    public String getBreakage(){
        return breakage;
    }
}
