
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class BicycleWorkshop{

    public String[] parserStrToObject(String str){
        String arrayStr[];
        arrayStr = str.split(" ");
        return arrayStr;
    }

    public static void main(String []args) throws ParserConfigurationException, SAXException, IOException, SQLException, ClassNotFoundException {
        ArrayList<Owner> lastOwners = new ArrayList<Owner>();
        ArrayList<Bicycle> lastBicycles = new ArrayList<Bicycle>();
        ArrayList<Repair> lastRepairs = new ArrayList<Repair>();

        String nameFile;

        Scanner number = new Scanner(System.in);

        System.out.println("Введите название файла включая расширение!");
        nameFile = number.nextLine();
        String exspansion[] = nameFile.split("\\.");

        switch(exspansion[exspansion.length - 1]){
            case("xml"):
            {
                if(new File("src/XML/" + nameFile).exists()){
                    System.out.println("Вы выбрали работу с " + exspansion[exspansion.length - 1] + " расширением файла!");

                    XML file = new XML();
                    file.connectXML(nameFile);

                    BicycleWorkshop tempObjectBicycleWorkshop = new BicycleWorkshop();

                    ArrayList <String> arrayStr = file.get();

                    for(int i = 0; i < arrayStr.size(); i++){
                        Bicycle tempObjectBicycle = new Bicycle();
                        Owner tempObjectOwner= new Owner();
                        Repair tempObjectRepair = new Repair();

                        String tempStr = arrayStr.get(i);
                        String strToArgs[] = tempObjectBicycleWorkshop.parserStrToObject(tempStr);

                        if(i < lastOwners.size()){
                            tempObjectBicycle.set(strToArgs[5], strToArgs[6]);
                            lastBicycles.set(i, tempObjectBicycle);

                            tempObjectOwner.set(strToArgs[0], strToArgs[1], strToArgs[2], strToArgs[4], strToArgs[9]);
                            lastOwners.set(i, tempObjectOwner);

                            tempObjectRepair.set(strToArgs[7]);
                            lastRepairs.set(i, tempObjectRepair);
                        }
                        else{
                            tempObjectBicycle.set(strToArgs[5], strToArgs[6]);
                            lastBicycles.add(tempObjectBicycle);

                            tempObjectOwner.set(strToArgs[0], strToArgs[1], strToArgs[2], strToArgs[4], strToArgs[9]);
                            lastOwners.add(tempObjectOwner);

                            tempObjectRepair.set(strToArgs[7]);
                            lastRepairs.add(tempObjectRepair);
                        }
                    }

                    ArrayList<Owner> owners = lastOwners;
                    ArrayList<Bicycle> bicycles = lastBicycles;
                    ArrayList<Repair> repairs = lastRepairs;

                    // какая либо работа с данными
                    bicycles.get(0).replace(bicycles);


                    // обратная замена в файле list.xml
                    file.replace(owners, bicycles, repairs);

                    break;
                }
                else{
                    System.out.println("Невозможно открыть выбранный вами фаил! Вероятная причина: не существует такого файла!");
                    break;
                }
            }
            case("db"):
            {
                if(new File("src/SQL/" + nameFile).exists()){
                    System.out.println("Вы выбрали работу с " + exspansion[exspansion.length - 1] + " расширением файла!");

                    SQLite file = new SQLite();
                    file.connectSQLite();

                    ArrayList<Owner> owners = lastOwners;
                    ArrayList<Bicycle> bicycles = lastBicycles;
                    ArrayList<Repair> repairs = lastRepairs;

                    file.replace(owners, bicycles, repairs);


                    break;
                }
                else{
                    System.out.println("Невозможно открыть выбранный вами фаил! Вероятная причина: не существует такого файла!");
                    break;
                }

            }
            default:
                System.out.println("Программа не может работать с таким(" + exspansion[exspansion.length - 1] + ") расширением файла!");
        }
    }
}
