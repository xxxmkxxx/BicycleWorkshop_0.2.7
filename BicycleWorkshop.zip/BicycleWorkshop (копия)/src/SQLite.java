import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class SQLite{
    private Connection co = null;
    private Statement stat;

    public void connectSQLite(){
        try {{
        try {
            Class.forName("org.sqlite.JDBC");
            this.co = DriverManager.getConnection("jdbc:sqlite:src/SQL/sqlite.db");
            System.out.println("Connected");
        }catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }
            Class.forName("org.sqlite.JDBC");
            this.co = DriverManager.getConnection("jdbc:sqlite:src/SQL/sqlite.db");
            System.out.println("Connected");
        }catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void replace(ArrayList<Owner> owners, ArrayList<Bicycle> bicycles, ArrayList<Repair> repairs) throws SQLException {
        String sql;

        for(int i = 0; i < owners.size(); i++){
            sql = "INSERT INTO customers('name')VALUES('ohhhhhh');";
            this.stat = co.createStatement();
            this.stat.execute(sql);
        }
    }
}